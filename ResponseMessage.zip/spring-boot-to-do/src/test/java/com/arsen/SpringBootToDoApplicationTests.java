package com.arsen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootToDoApplicationTests {

	@Test
	void contextLoads() {
	}

}
