package com.arsen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootToDoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootToDoApplication.class, args);
	}

}
