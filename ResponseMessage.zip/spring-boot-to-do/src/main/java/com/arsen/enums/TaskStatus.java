package com.arsen.enams;

public enum TaskStatus {
    NEW, IN_PROGRESS, COMPLETED
}
